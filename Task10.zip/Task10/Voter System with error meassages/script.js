function validateForm(event) {
    event.preventDefault();

    const fullName = document.getElementById('fullName').value;
    const age = document.getElementById('age').value;
    const nameError = document.getElementById('nameError');
    const ageError = document.getElementById('ageError');
    let isValid = true;

    // Reset error messages
    nameError.textContent = '';
    ageError.textContent = '';

    // Validate full name
    if (fullName.trim() === '') {
        nameError.textContent = 'Please enter your full name';
        isValid = false;
    }

    // Validate age
    if (isNaN(age) || age < 18) {
        ageError.textContent = 'Age must be a number and 18+';
        isValid = false;
    }

    // If form is valid, proceed
    if (isValid) {
        alert('Congratulations! You are eligible to vote.');
        // Here you can submit the form or redirect to another page
    }
}
